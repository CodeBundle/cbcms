<?php 
include $_SERVER['DOCUMENT_ROOT'].'/data/head.html';
include $_SERVER['DOCUMENT_ROOT'].'/data/body.php';
include $_SERVER['DOCUMENT_ROOT'].'/data/mainbody.php';
?>
