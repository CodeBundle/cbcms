<?php
include $_SERVER['DOCUMENT_ROOT'].'/data/head.php';
include $_SERVER['DOCUMENT_ROOT'].'/data/body.php';
include $_SERVER['DOCUMENT_ROOT'].'/data/blogbody.php';
?>